module OtherModule where

magicalString = "Hello World!"