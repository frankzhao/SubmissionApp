import OtherModule

main = putStrLn magicalString -- this comes from OtherModule.hs