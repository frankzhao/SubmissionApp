// MyFancyGame module

// ...
(function(root) {
  var MyFancyGame = root.MyFancyGame = {};

  var Ship = MyFancyGame.Ship = function (name) { this.name = name; };

  Ship.prototype.power = function () { return "power" };
  Ship.prototype.turn = function () { return "turn" };
  Ship.prototype.fireBullet = function () { return "fireBullet" };

  var Spaceman = MyFancyGame.Spaceman = function (name) { this.name = name; };

  Spaceman.prototype.walk = function () { return "walk" };
  Spaceman.prototype.work = function () { return "work" };
  Spaceman.prototype.moonwalk = function () { return "moonwalk" };

})(this)