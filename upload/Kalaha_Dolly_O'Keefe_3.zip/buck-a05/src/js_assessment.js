// ...

(function(root) {
  var JSA = root.JSA = {};

  JSA.twoSum = function (arr) {
    for (var i = 0; i < arr.length; i++) {
      for (var j = i+1; j < arr.length; j++) {
        if (arr[i] + arr[j] == 0) {
          return true;
        }
      }
    }
    return false;
  };

  JSA.factors = function(n) {
    factors = [];
    for (var i=1; i<=n; i++) {
      if (Math.floor(n/i)*i == n) {
        factors.push(i);
      }
    }
    return factors;
  }

  JSA.fibonacci = function(n) {
    if (n<=1) {
      return 0;
    } else if (n==2) {
      return 1;
    } else {
      return JSA.fibonacci(n-1) + JSA.fibonacci(n-2);
    }
  }

  JSA.myBind = function(func, obj) {
    return function() {
      func.apply(obj, arguments);
    };
  }

  JSA.addThenDo = function(x, y, f) {
    f(x+y);
  }

  JSA.inherits = function(child, parent) {
    var Surrogate = function () {};
    Surrogate.prototype = parent.prototype;
    child.prototype = new Surrogate();
  };


})(this);
