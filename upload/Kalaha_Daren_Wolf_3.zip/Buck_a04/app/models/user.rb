class User < ActiveRecord::Base
  attr_accessible :password, :session_token, :username

  # before_save or something, I forget. ASK ABOUT THIS.

  validates :username, :password, :session_token, :presence => true
  validates :password, :length => { :minimum => 6 }

  def reset_session_token
    self.session_token = SecureRandom.urlsafe_base64(16)
  end

  def reset_session_token!
    reset_session_token
    self.save!
  end

  has_many :posts
end
