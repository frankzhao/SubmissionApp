class Post < ActiveRecord::Base
  attr_accessible :body, :title, :user_id

  validates :title, :body, :presence => true

  belongs_to :user
  has_many :tags
end
