class TagsController < ApplicationController
  def create
    tag = Tag.new(params[:tag])
    tag.post_id = params[:post_id]

    tag.save!

    redirect_to post_url(params[:post_id])
  end

  def destroy
    tag = Tag.find_by_id(params[:id])

    redirect_to post_url(params[:post_id])
    tag.destroy if tag
  end
end
