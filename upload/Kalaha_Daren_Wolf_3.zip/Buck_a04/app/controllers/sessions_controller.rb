class SessionsController < ApplicationController
  def new
    render :new
  end

  def create
    user = User.find_by_username_and_password(params[:user][:username],
                                              params[:user][:password])

    if user
      session[:session_token] = user.session_token
      redirect_to "/session/new"
    else
      flash[:errors] = ["Incorrect username/password"]
      render :new
    end
  end

  def destroy
    logout!
    redirect_to "/session/new"
  end
end
