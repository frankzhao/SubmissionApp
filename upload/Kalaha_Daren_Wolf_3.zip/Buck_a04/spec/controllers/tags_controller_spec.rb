require 'spec_helper'

describe TagsController do

end
