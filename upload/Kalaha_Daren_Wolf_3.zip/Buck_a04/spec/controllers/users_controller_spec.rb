require 'spec_helper'

describe UsersController do

end
