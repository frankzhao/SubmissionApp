require 'spec_helper'

describe PostsController do

end
