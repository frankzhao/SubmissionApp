# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Posts::Application.config.secret_token = '9f6fa093b67b76ceee6a495c29c17191d21dddbee4b880ddbc157edab3942dd8e61ee04ef318c43fd38cc7993350d4bb50491fdcd777e9e2ab6913950b058be6'
