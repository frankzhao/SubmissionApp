Posts::Application.routes.draw do
  resources :users, :only => [:create, :new]
  resource :session
  resources :posts do
    resources :tags
  end

end

