PostApp.Models.Post = Backbone.Model.extend({
  validate: function (attributes) {
  }
});
