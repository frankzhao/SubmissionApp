window.PostApp = {
  Models: {},
  Collections: {},
  Views: {},
  Routers: {},
  initialize: function() {
    PostApp.posts = new PostApp.Collections.Posts();
    new PostApp.Routers.Router({
      $rootEl: $("#content")
    });
    Backbone.history.start();
  }
};

JSA = {};

JSA.myBind = function (fn, obj) {};

JSA.myCall = function (fn, obj) {};

JSA.myCurry = function (fn, obj, numArgs) {};
