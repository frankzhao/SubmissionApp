PostApp.Routers.Router = Backbone.Router.extend({
  initialize: function (options) {
  },

  routes: {
  },

  edit: function (id) {
  },

  index: function () {
  },

  new: function () {
  },

  show: function (id) {
  },


  // these methods are not tested, but you might find them useful
  _getPost: function (id, callback) {
  },

  _swapView: function (view) {
   }
});
