describe("PostApp.Models.Post model", function () {
  it("will validate that the title is not blank, (validate method in Post)", function () {
    var post = new PostApp.Models.Post({ title: "" });
    expect(post.validate()).toEqual("cannot have an empty title");
  });
});
