describe("PostApp.Routers.Router - handlers", function() {
  beforeEach(function () {
    this.$rootEl = $('<div>');
    this.router = new PostApp.Routers.Router({
      $rootEl: this.$rootEl
    });

    PostApp.posts.add(new PostApp.Models.Post({ id: 1 }));
  });

  describe("#index handler", function() {
    it("renders the Post Index template into $rootEl", function () {
      this.router.index();
      expect(this.$rootEl.text()).toMatch(/Post Index View/);
    });
  });

  describe("#show handler", function () {
    it("renders the Post Show template into $rootEl", function () {
      this.router.show("1");
      expect(this.$rootEl.text()).toMatch(/Post Show View/);
    });
  });

  describe("#new handler", function () {
    it("renders the Post Form template into $rootEl", function () {
      this.router.new();
      expect(this.router.$rootEl.text()).toMatch(/Submit/);
    });
  });

  describe("#edit handler", function () {
    it("renders the Post Form template into $rootEl", function () {
      this.router.edit("1");
      expect(this.router.$rootEl.text()).toMatch(/Submit/);
    });
  });
});
