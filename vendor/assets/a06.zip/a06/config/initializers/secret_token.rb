# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BackboneAssessment::Application.config.secret_token = '788e877538b816480f402b44a61b0bc9fe8a2d91139a9a6590e7966ebf838e6a89cdd3150874d37d425f898786e0d23c38656d2496126a81cd57a637c0335357'
